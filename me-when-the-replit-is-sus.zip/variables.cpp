#include <iostream>

using namespace std;

//variables

int main() 
{
  string MyName = "Oscar";
  int number;
  number = 86;
  cout << "There once was a boy named " << MyName << endl;
  cout << "He had an alter ego named Niko" << endl;
  cout << "Niko is in every single way better than " << MyName << endl;
  cout << "Niko only exists to keep " << MyName << " sane" << endl;
  cout << "Niko has the nickname '" << number << "'" << endl;
  cout << MyName <<"'s favorite number so happens to also be " << number <<"... coincedince? I THINK NOT!" << endl;
  return 0;
}


#include <iostream>

using namespace std;

//data types

int second()
{
  char grade = 'A';
  string phrase = "get trolled"; 
  int sexnumber = 69;
  double thetime = 11.49; //PM please help me i'm learing C++ at midnight like I know I have no life and 4 months of nothing but sheeesh dude
  bool isgay = true;
  return 0;
}